import glob
import requests
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
import os
import tarfile
import shutil

Main_url = "https://ted.europa.eu/en/simap/xml-bulk-download"
download_dir = "Data/Raw"
extract_dir = "Data/Extracted"

# Create necessary folders
os.makedirs(download_dir, exist_ok=True)
os.makedirs(extract_dir, exist_ok=True)

# -------------------------------------------------
# CLEAN EXTRACTED FOLDER BEFORE NEW RUN
# -------------------------------------------------
def clean_extracted_folder():
    if os.path.exists(extract_dir):
        shutil.rmtree(extract_dir)
    os.makedirs(extract_dir, exist_ok=True)
    print("[INFO] Extracted folder cleaned and refreshed.")

clean_extracted_folder()
# -------------------------------------------------

# Get today's date for checking
# today = datetime.today().strftime('%d/%m/%Y')

today1 = datetime.today() - timedelta(3)
today = threshold = today1.strftime('%d/%m/%Y')
print(f"[INFO] Looking for file dated: {today}")

# Fetch page
response = requests.get(Main_url)
soup = BeautifulSoup(response.text, "html.parser")

# Find latest file
downloaded = False

for row in soup.select("table tbody tr"):
    if today in row.text:
        try:
            link_tag = row.select_one("td:nth-child(3) a")
            file_url = link_tag['href']
            filename = file_url.split("/")[-1]

            # Ensure file has .tar.gz extension
            if not filename.endswith(".tar.gz"):
                filename += ".tar.gz"

            file_path = os.path.join(download_dir, filename)

            # Download
            print(f"[INFO] Downloading: {filename}")
            with requests.get(file_url, stream=True) as r:
                r.raise_for_status()
                with open(file_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)

            print(f"[INFO] Downloaded to: {file_path}")
            downloaded = True

            # Validate & Extract
            if tarfile.is_tarfile(file_path):
                with tarfile.open(file_path, "r:gz") as tar:
                    folder_name = tar.getnames()[0].split('/')[0]
                    output_path = os.path.join(extract_dir, folder_name)
                    os.makedirs(output_path, exist_ok=True)
                    tar.extractall(path=output_path)
                    print(f"[INFO] Extracted to: {output_path}")

                    # List extracted XML files
                    xml_files = glob.glob(os.path.join(output_path, "*", "*.xml"))
                    print(f"[INFO] Total XML files extracted: {len(xml_files)}")
            else:
                print("[ERROR] Downloaded file is not a valid tar archive.")

            break
        except Exception as e:
            print(f"[ERROR] Failed to download or extract: {e}")
            break

if not downloaded:
    print("[INFO] No file found for today.")
