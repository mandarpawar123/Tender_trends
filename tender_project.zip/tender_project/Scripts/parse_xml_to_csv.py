import os
from dateutil import parser
import re
import csv
import xml.etree.ElementTree as ET
from datetime import datetime, timezone


# Namespace map (common in TED/eForms XMLs, adjust if needed)
ns = {
    '': 'urn:oasis:names:specification:ubl:schema:xsd:ContractNotice-2',  # default namespace
    'cac': 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2',
    'cbc': 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2',
    'efac': 'http://data.europa.eu/p27/eforms-ubl-extension-aggregate-components/1',
    'efbc': 'http://data.europa.eu/p27/eforms-ubl-extension-basic-components/1',
    'efext': 'http://data.europa.eu/p27/eforms-ubl-extensions/1',
    'ext': 'urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2'
}


# Input & output folders

# Input & output folders
xml_folder = r"Data\Extracted"
output_file = r"csv\tenders.csv"



# Define CSV headers
headers = [
    "TenderID",
    "NoticeType",
    "PublicationDate",
    "Title",
    "BuyerName",
    "Country",
    "CPVCodes",
    "Deadline"
]

def parse_xml(xml_file):
    tree = ET.parse(xml_file)
    root = tree.getroot()

    # Extract fields safely (return None if not found)
    tender_id = root.findtext('.//cbc:ID', default="", namespaces=ns)
    id_element = root.find(".//cbc:NoticeTypeCode", namespaces=ns)
    notice_type = id_element.attrib.get("listName")
    pub_date = root.findtext('.//efbc:PublicationDate', default="", namespaces=ns)
    title = root.findtext('.//cac:ProcurementProject/cbc:Name', default="", namespaces=ns)
    buyer = root.findtext(
            './/efac:Organization/efac:Company/cac:PartyName/cbc:Name',
            default="", namespaces=ns
        )

# Buyer country code (from PostalAddress -> Country -> IdentificationCode)
    country = root.findtext(
        './/efac:Organization/efac:Company/cac:PostalAddress/cac:Country/cbc:IdentificationCode',
        default="", namespaces=ns
    )
    cpv = root.findtext('.//cbc:ItemClassificationCode', default="", namespaces=ns)
    deadline = root.findtext('.//cbc:EndDate', default="", namespaces=ns)

    return {
        "TenderID": tender_id,
        "NoticeType": notice_type,
        "PublicationDate": pub_date,
        "Title": title,
        "BuyerName": buyer,
        "Country": country,
        "CPVCodes": cpv,
        "Deadline": deadline
    }

def main():
    rows = []

    for root, dirs, files in os.walk(xml_folder):
        for filename in files:
            if filename.endswith(".xml"):
                file_path = os.path.join(root, filename)
                try:
                    data = parse_xml(file_path)
                    rows.append(data)
                except Exception as e:
                    print(f"Error parsing {filename}: {e}")

    # After collecting all rows
    # After collecting all rows
    for row in rows:
        if row["PublicationDate"]:
            pub = row["PublicationDate"].strip()

            # YYYY-MM-DD+hh:mm → strip timezone
            if re.match(r"^\d{4}-\d{2}-\d{2}\+\d{2}:\d{2}$", pub):
                pub = pub.split("+")[0]

            # YYYY-MM-DDZ → strip Z
            if re.match(r"^\d{4}-\d{2}-\d{2}Z$", pub):
                pub = pub.replace("Z", "")

            try:
                dt = datetime.strptime(pub, "%Y-%m-%d")
                row["PublicationDate"] = dt.strftime("%Y-%m-%d %H:%M:%S")
            except:
                row["PublicationDate"] = pub  # fallback

        if row["Deadline"]:
            dl = row["Deadline"].strip()

            if re.match(r"^\d{4}-\d{2}-\d{2}\+\d{2}:\d{2}$", dl):
                dl = dl.split("+")[0]

            if re.match(r"^\d{4}-\d{2}-\d{2}Z$", dl):
                dl = dl.replace("Z", "")

            try:
                dt = datetime.strptime(dl, "%Y-%m-%d")
                row["Deadline"] = dt.strftime("%Y-%m-%d %H:%M:%S")
            except:
                row["Deadline"] = dl

    # Save to CSV
    output_file = r"csv\tenders.csv"

    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    with open(output_file, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)

if __name__ == "__main__":
    main()
