import pandas as pd
import mysql.connector
import re
import os

# -----------------------------
# Step 1: Read and normalize CSV
# -----------------------------
input_file = r"csv\tenders_clean.csv"

if not os.path.exists(input_file):
    print(f"Input file not found: {input_file}")
    exit()

df = pd.read_csv(input_file)

# Normalize column names: remove spaces
df.columns = [c.strip() for c in df.columns]

# Debug: check column names
print("Columns found in CSV:", df.columns.tolist())

# -----------------------------
# Step 2: Connect to MySQL
# ---------------w--------------
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="admin",
    database="my_tender_db",
    autocommit=True
)
cursor = connection.cursor()

# Create table if not exists
cursor.execute("""
CREATE TABLE IF NOT EXISTS tenders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    TenderID VARCHAR(50),
    NoticeType VARCHAR(50),
    PublicationDate DATE,
    Title TEXT,
    BuyerName VARCHAR(1000),
    Country VARCHAR(100),
    CPVCodes VARCHAR(100),
    Deadline DATE
)
""")

# -----------------------------
# 🧹 Step 3: Clear old dataVA
# -----------------------------
print("[INFO] Clearing old records...")
cursor.execute("TRUNCATE TABLE tenders;")
connection.commit()
print("[INFO] Old data removed successfully!")

# -----------------------------
# Step 4: Insert new data
# -----------------------------
for index, row in df.iterrows():
    tender_id = None if pd.isna(row.get("TenderID")) else str(row["TenderID"]).strip()
    notice_type = None if pd.isna(row.get("NoticeType")) else str(row["NoticeType"]).strip()

    pub_date = row.get("PublicationDate")
    if pd.isna(pub_date) or str(pub_date).strip() == "":
        pub_date = None
    else:
        pub_date = re.sub(r'Z$|T.*', '', str(pub_date)).strip()

    deadline = row.get("Deadline")
    if pd.isna(deadline) or str(deadline).strip() == "":
        deadline = None
    else:
        deadline = re.sub(r'Z$|T.*', '', str(deadline)).strip()

    title = "" if pd.isna(row.get("Title")) else str(row["Title"]).strip()
    buyer = "" if pd.isna(row.get("BuyerName")) else str(row["BuyerName"]).strip()
    country = "" if pd.isna(row.get("Country")) else str(row["Country"]).strip()
    cpv = "" if pd.isna(row.get("CPVCodes")) else str(row["CPVCodes"]).strip()

    insert_query = """
        INSERT INTO tenders 
        (TenderID, NoticeType, PublicationDate, Title, BuyerName, Country, CPVCodes, Deadline)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """
    values = (tender_id, notice_type, pub_date, title, buyer, country, cpv, deadline)

    try:
        cursor.execute(insert_query, values)
    except Exception as e:
        print(f"[WARNING] Skipped row {index} → {e}")
        continue

connection.commit()
cursor.close()
connection.close()

print("✅ Fresh CSV data successfully inserted into MySQL database!")
