import pandas as pd
import os

input_file = r"csv\tenders.csv"
output_file = r"csv\tenders_clean.csv"

def clean_csv(input_file, output_file):
    if not os.path.exists(input_file):
        print(f"❌ Input file not found: {input_file}")
        return

    # Load CSV
    df = pd.read_csv(input_file)

    # --- Cleaning Steps ---
    # 1. Drop completely empty columns
    df = df.dropna(axis=1, how='all')

    # 2. Drop duplicate rows if any
    df = df.drop_duplicates()

    # 3. For result rows, keep Deadline empty (NULL in MySQL)
    if "Deadline" in df.columns and "NoticeType" in df.columns:
        result_mask = df["NoticeType"].str.lower() == "result"
        # Ensure missing deadlines remain NaN
        df.loc[result_mask, "Deadline"] = df.loc[result_mask, "Deadline"].replace('', pd.NA)

    # 4. Fill remaining NaN in other columns with empty string
    for col in df.columns:
        if col != "Deadline":  # Skip Deadline so MySQL can use NULL
            df[col] = df[col].fillna("")

    # 5. Format PublicationDate
    if "PublicationDate" in df.columns:
        df["PublicationDate"] = pd.to_datetime(df["PublicationDate"], errors="coerce")
        df["PublicationDate"] = df["PublicationDate"].dt.strftime("%Y-%m-%d %H:%M:%S")

    if "CPVCodes" in df.columns:
        df["CPVCodes"] = df["CPVCodes"].astype(str).str.zfill(8)

    # 6. Format Deadline only for actual dates (keep NaN for result rows)
    if "Deadline" in df.columns:
        def format_deadline(x):
            try:
                return pd.to_datetime(x).strftime("%Y-%m-%d %H:%M:%S")
            except:
                return pd.NA  # Keep as NULL-ready
        df["Deadline"] = df["Deadline"].apply(format_deadline)

    # Save cleaned CSV
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    df.to_csv(output_file, index=False, encoding="utf-8")

    print(f"✅ Cleaned CSV saved at: {output_file}")

if __name__ == "__main__":
    clean_csv(input_file, output_file)
