import pandas as pd

df = pd.read_csv("csv\\tenders_clean.csv")
print(df.isna().sum())

